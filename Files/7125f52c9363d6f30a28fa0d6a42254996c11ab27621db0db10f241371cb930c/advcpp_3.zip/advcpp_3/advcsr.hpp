#ifndef ADVCSR_HPP
#define ADVCSR_HPP

#include <iostream>
#include <cstdlib>
#include <cstring>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

namespace adv {

class Cursor {
private:
    bool supportsAnsi = false;
    bool isWindows = false;
    
#ifdef _WIN32
    HANDLE hConsole = nullptr;
#endif
    
    void checkAnsi() {
#ifdef _WIN32
        isWindows = true;
        hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        
        if (hConsole != INVALID_HANDLE_VALUE) {
            // Try to enable ANSI support
            DWORD mode = 0;
            if (GetConsoleMode(hConsole, &mode)) {
                // Use #ifndef to check if ENABLE_VIRTUAL_TERMINAL_PROCESSING is defined
                #ifndef ENABLE_VIRTUAL_TERMINAL_PROCESSING
                    #define ENABLE_VIRTUAL_TERMINAL_PROCESSING 0x0004
                #endif
                
                mode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
                
                if (SetConsoleMode(hConsole, mode)) {
                    supportsAnsi = true;
                    return; // Success
                }
                
                // Reset mode and check for third-party ANSI support
                GetConsoleMode(hConsole, &mode);
                
                // Check for ANSICON or terminal emulators
                const char* ansicon = getenv("ANSICON");
                const char* conemu = getenv("ConEmuANSI");
                const char* wtSession = getenv("WT_SESSION"); // Windows Terminal
                
                if ((ansicon != nullptr) || 
                    (conemu != nullptr && strcmp(conemu, "ON") == 0) ||
                    (wtSession != nullptr)) {
                    supportsAnsi = true;
                    return; // Third-party ANSI support available
                }
            }
            
            // No ANSI support
            supportsAnsi = false;
            return;
        }
        
        supportsAnsi = false;
#else
        isWindows = false;
        if (!isatty(STDOUT_FILENO)) {
            supportsAnsi = false;
            return;
        }
        const char* term = std::getenv("TERM");
        if (term != nullptr) {
            if (std::strstr(term, "xterm") != nullptr ||
                std::strstr(term, "ansi") != nullptr ||
                std::strstr(term, "vt100") != nullptr ||
                std::strstr(term, "vt220") != nullptr ||
                std::strstr(term, "linux") != nullptr ||
                std::strstr(term, "screen") != nullptr ||
                std::strstr(term, "tmux") != nullptr ||
                std::strstr(term, "rxvt") != nullptr) {
                supportsAnsi = true;
                return;
            }
            if (std::strstr(term, "dumb") != nullptr ||
                std::strstr(term, "unknown") != nullptr) {
                supportsAnsi = false;
                return;
            }
        }
        if (std::getenv("COLORTERM") != nullptr) {
            supportsAnsi = true;
            return;
        }
        supportsAnsi = true;
#endif
    }

public:
    Cursor() {
        checkAnsi();
#ifdef _WIN32
        hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
#endif
    }
    
    ~Cursor() {
        show(true);
    }
    
    bool supportsANSI() const { return supportsAnsi; }
    
    void gotoxy(int x, int y) {
        if (supportsAnsi) {
            std::cout << "\033[" << (y + 1) << ";" << (x + 1) << "H" << std::flush;
        } else {
            if (isWindows) {
#ifdef _WIN32
                COORD coord;
                coord.X = static_cast<SHORT>(x);
                coord.Y = static_cast<SHORT>(y);
                SetConsoleCursorPosition(hConsole, coord);
#endif
            } else {
                for (int i = 0; i < y; ++i) std::cout << '\n';
                for (int i = 0; i < x; ++i) std::cout << ' ';
                std::cout << std::flush;
            }
        }
    }
    
    void clear() {
        if (supportsAnsi) {
            std::cout << "\033[2J\033[H" << std::flush;
        } else {
            if (isWindows) system("cls");
            else system("clear");
        }
    }
    
    void clearLine() {
        if (supportsAnsi) {
            std::cout << "\033[2K" << std::flush;
        } else {
            if (isWindows) {
#ifdef _WIN32
                CONSOLE_SCREEN_BUFFER_INFO csbi;
                GetConsoleScreenBufferInfo(hConsole, &csbi);
                COORD start = csbi.dwCursorPosition;
                DWORD length = csbi.dwSize.X - start.X;
                DWORD written;
                FillConsoleOutputCharacter(hConsole, ' ', length, start, &written);
                FillConsoleOutputAttribute(hConsole, csbi.wAttributes, length, start, &written);
#endif
            } else {
                std::cout << std::endl;
            }
        }
    }
    
    void show(bool visible = true) {
        if (supportsAnsi) {
            if (visible) std::cout << "\033[?25h" << std::flush;
            else std::cout << "\033[?25l" << std::flush;
        } else {
            if (isWindows) {
#ifdef _WIN32
                CONSOLE_CURSOR_INFO cursorInfo;
                GetConsoleCursorInfo(hConsole, &cursorInfo);
                cursorInfo.bVisible = visible;
                SetConsoleCursorInfo(hConsole, &cursorInfo);
#endif
            }
        }
    }
    
    void hide() { show(false); }
};

// Global instance
static Cursor advcsr;

} // namespace adv

#endif // ADVCSR_HPP