#ifndef ADVOUT_HPP
#define ADVOUT_HPP

#include <iostream>
#include <cstdarg>
#include <cstring>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

namespace adv {

// Color enumeration
enum color {
    BLACK = 0, RED = 1, GREEN = 2, YELLOW = 3, BLUE = 4,
    MAGENTA = 5, CYAN = 6, WHITE = 7, GRAY = 8,
    BRIGHT_RED = 9, BRIGHT_GREEN = 10, BRIGHT_YELLOW = 11,
    BRIGHT_BLUE = 12, BRIGHT_MAGENTA = 13, BRIGHT_CYAN = 14,
    BRIGHT_WHITE = 15, RESET_COLOR = 16
};

// Text attributes
enum attributes {
    RESET = 0, BOLD = 1, FAINT = 2, ITALIC = 3, UNDERLINE = 4,
    BLINK_SLOW = 5, BLINK_FAST = 6, REVERSE = 7,
    CONCEAL = 8, STRIKETHROUGH = 9
};

class DualSupportOutput {
private:
    bool supportsAnsi;
    bool isWindows;
    bool winConsoleColorsEnabled;
#ifdef _WIN32
    HANDLE hConsole;
    WORD winConsoleDefaultAttributes;
#endif
    int settings[6]; // fr, fg, fb, br, bg, bb
    
#ifdef _WIN32
    // Windows Console API color constants (using Windows constants directly)
    enum WinConsoleColor {
        WIN_COLOR_BLACK         = 0,
        WIN_COLOR_DARK_BLUE     = 1,
        WIN_COLOR_DARK_GREEN    = 2,
        WIN_COLOR_DARK_CYAN     = 3,
        WIN_COLOR_DARK_RED      = 4,
        WIN_COLOR_DARK_MAGENTA  = 5,
        WIN_COLOR_DARK_YELLOW   = 6,
        WIN_COLOR_GRAY          = 7,
        WIN_COLOR_DARK_GRAY     = 8,
        WIN_COLOR_BLUE          = 9,
        WIN_COLOR_GREEN         = 10,
        WIN_COLOR_CYAN          = 11,
        WIN_COLOR_RED           = 12,
        WIN_COLOR_MAGENTA       = 13,
        WIN_COLOR_YELLOW        = 14,
        WIN_COLOR_WHITE         = 15
    };
    
    // Map ANSI color codes to Windows Console colors
    WORD ansiColorToWinColor(int ansiCode) {
        switch (ansiCode) {
            case 30: return 0;  // BLACK
            case 31: return 12; // RED
            case 32: return 10; // GREEN
            case 33: return 14; // YELLOW
            case 34: return 9;  // BLUE
            case 35: return 13; // MAGENTA
            case 36: return 11; // CYAN
            case 37: return 15; // WHITE
            case 90: return 8;  // DARK_GRAY
            case 91: return 12; // BRIGHT_RED
            case 92: return 10; // BRIGHT_GREEN
            case 93: return 14; // BRIGHT_YELLOW
            case 94: return 9;  // BRIGHT_BLUE
            case 95: return 13; // BRIGHT_MAGENTA
            case 96: return 11; // BRIGHT_CYAN
            case 97: return 15; // BRIGHT_WHITE
            default: return winConsoleDefaultAttributes & 0x0F;
        }
    }
    
    // Convert WinConsoleColor to actual console attributes
    WORD getWinConsoleColor(WORD colorCode) {
        // Map our constants to actual console attributes
        static const WORD colorMap[16] = {
            0,                                          // BLACK
            FOREGROUND_BLUE,                            // DARK_BLUE
            FOREGROUND_GREEN,                           // DARK_GREEN
            FOREGROUND_GREEN | FOREGROUND_BLUE,         // DARK_CYAN
            FOREGROUND_RED,                             // DARK_RED
            FOREGROUND_RED | FOREGROUND_BLUE,           // DARK_MAGENTA
            FOREGROUND_RED | FOREGROUND_GREEN,          // DARK_YELLOW
            FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE, // GRAY
            FOREGROUND_INTENSITY,                       // DARK_GRAY
            FOREGROUND_INTENSITY | FOREGROUND_BLUE,     // BLUE
            FOREGROUND_INTENSITY | FOREGROUND_GREEN,    // GREEN
            FOREGROUND_INTENSITY | FOREGROUND_GREEN | FOREGROUND_BLUE, // CYAN
            FOREGROUND_INTENSITY | FOREGROUND_RED,      // RED
            FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_BLUE, // MAGENTA
            FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN, // YELLOW
            FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE // WHITE
        };
        
        if (colorCode < 16) {
            return colorMap[colorCode];
        }
        return winConsoleDefaultAttributes & 0x0F;
    }
    
    // Set color using Windows Console API
    void setWinConsoleColor(WORD colorCode) {
        if (!winConsoleColorsEnabled || hConsole == INVALID_HANDLE_VALUE) {
            return;
        }
        WORD actualColor = getWinConsoleColor(colorCode);
        SetConsoleTextAttribute(hConsole, actualColor);
    }
    
    // Reset to default colors using Windows Console API
    void resetWinConsoleColor() {
        if (!winConsoleColorsEnabled || hConsole == INVALID_HANDLE_VALUE) {
            return;
        }
        SetConsoleTextAttribute(hConsole, winConsoleDefaultAttributes);
    }
#endif
    
    void checkAnsi() {
#ifdef _WIN32
        isWindows = true;
        winConsoleColorsEnabled = false;
        hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        
        if (hConsole != INVALID_HANDLE_VALUE) {
            // Try to enable ANSI support using dynamic approach
            DWORD mode = 0;
            if (GetConsoleMode(hConsole, &mode)) {
                // Use #ifndef to check if ENABLE_VIRTUAL_TERMINAL_PROCESSING is defined
                #ifndef ENABLE_VIRTUAL_TERMINAL_PROCESSING
                    #define ENABLE_VIRTUAL_TERMINAL_PROCESSING 0x0004
                #endif
                
                mode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
                
                if (SetConsoleMode(hConsole, mode)) {
                    supportsAnsi = true;
                    return; // Success - using ANSI codes
                }
                
                // Reset mode and check for third-party ANSI support
                GetConsoleMode(hConsole, &mode);
                
                // Check for ANSICON or terminal emulators
                const char* ansicon = getenv("ANSICON");
                const char* conemu = getenv("ConEmuANSI");
                const char* wtSession = getenv("WT_SESSION"); // Windows Terminal
                
                if ((ansicon != nullptr) || 
                    (conemu != nullptr && strcmp(conemu, "ON") == 0) ||
                    (wtSession != nullptr)) {
                    supportsAnsi = true;
                    return; // Third-party ANSI support available
                }
            }
            
            // No ANSI support - initialize Windows Console API for colors
            supportsAnsi = false;
            winConsoleColorsEnabled = true;
            
            // Get default console attributes
            CONSOLE_SCREEN_BUFFER_INFO csbi;
            if (GetConsoleScreenBufferInfo(hConsole, &csbi)) {
                winConsoleDefaultAttributes = csbi.wAttributes;
            } else {
                winConsoleDefaultAttributes = 7; // Default gray on black
            }
            
            return;
        }
        
        // No console available
        supportsAnsi = false;
        winConsoleColorsEnabled = false;
        hConsole = INVALID_HANDLE_VALUE;
#else
        isWindows = false;
        winConsoleColorsEnabled = false;
        
        if (!isatty(STDOUT_FILENO)) {
            supportsAnsi = false;
            return;
        }
        const char* term = std::getenv("TERM");
        if (term != nullptr) {
            if (std::strstr(term, "xterm") != nullptr ||
                std::strstr(term, "ansi") != nullptr ||
                std::strstr(term, "vt100") != nullptr ||
                std::strstr(term, "vt220") != nullptr ||
                std::strstr(term, "linux") != nullptr ||
                std::strstr(term, "screen") != nullptr ||
                std::strstr(term, "tmux") != nullptr ||
                std::strstr(term, "rxvt") != nullptr) {
                supportsAnsi = true;
                return;
            }
            if (std::strstr(term, "dumb") != nullptr ||
                std::strstr(term, "unknown") != nullptr) {
                supportsAnsi = false;
                return;
            }
        }
        if (std::getenv("COLORTERM") != nullptr) {
            supportsAnsi = true;
            return;
        }
        supportsAnsi = true;
#endif
    }
    
    // RGB to ANSI mapping
    static inline const int rgbansi[17][3] = {
        {0, 0, 0}, {255, 0, 0}, {0, 255, 0}, {255, 255, 0},
        {0, 0, 255}, {255, 0, 255}, {0, 255, 255}, {255, 255, 255},
        {128, 128, 128}, {255, 128, 128}, {128, 255, 128},
        {255, 255, 128}, {128, 128, 255}, {255, 128, 255},
        {128, 255, 255}, {255, 255, 255}, {-1, -1, -1}
    };

public:
    DualSupportOutput() {
        checkAnsi();
        for(int i = 0; i < 6; i++) settings[i] = -1;
        reset();
    }
    
    void clearScreen() {
        if (supportsAnsi) {
            std::cout << "\033[2J\033[1;1H";
        } else {
            if (isWindows) std::system("cls");
            else std::system("clear");
        }
        std::cout.flush();
    }
    
    bool hasAnsi() const { return supportsAnsi; }
    bool isWindowsPlatform() const { return isWindows; }
    bool hasWinConsoleColors() const { return winConsoleColorsEnabled; }
    
    void showInfo() {
        printline("System info"); 
        printline(std::string(hasAnsi() ? "Supports" : "Does not support") + " ANSI");
        printline("Platform: " + std::string(isWindowsPlatform() ? "Windows" : "Unix-like"));
        if (isWindowsPlatform()) {
            printline(std::string(hasWinConsoleColors() ? "Using Windows Console API" : "No console colors available"));
        }
    }
    
    void setForegroundColor(int r, int g, int b) {
        if (supportsAnsi) {
            if (r == -1 || g == -1 || b == -1) std::cout << "\033[39m";
            else std::cout << "\033[38;2;" << r << ";" << g << ";" << b << "m";
            settings[0] = r; settings[1] = g; settings[2] = b;
        }
#ifdef _WIN32
        else if (winConsoleColorsEnabled) {
            // Simple mapping for basic colors
            if (r == -1 || g == -1 || b == -1) {
                resetWinConsoleColor();
            }
        }
#endif
    }
    
    void setForegroundColor(color color) {
        if (supportsAnsi) {
            int index = static_cast<int>(color);
            if (index >= 0 && index < 17) {
                setForegroundColor(rgbansi[index][0], rgbansi[index][1], rgbansi[index][2]);
            }
        }
#ifdef _WIN32
        else if (winConsoleColorsEnabled) {
            // Map our color enum to Windows console colors
            static const WORD winColorMap[17] = {
                0,   // BLACK
                12,  // RED
                10,  // GREEN
                14,  // YELLOW
                9,   // BLUE
                13,  // MAGENTA
                11,  // CYAN
                15,  // WHITE
                8,   // GRAY
                12,  // BRIGHT_RED
                10,  // BRIGHT_GREEN
                14,  // BRIGHT_YELLOW
                9,   // BRIGHT_BLUE
                13,  // BRIGHT_MAGENTA
                11,  // BRIGHT_CYAN
                15,  // BRIGHT_WHITE
                winConsoleDefaultAttributes & 0x0F  // RESET_COLOR
            };
            
            int index = static_cast<int>(color);
            if (index >= 0 && index < 17) {
                setWinConsoleColor(winColorMap[index]);
            }
        }
#endif
    }
    
    void setBackgroundColor(int r, int g, int b) {
        if (supportsAnsi) {
            if (r == -1 || g == -1 || b == -1) std::cout << "\033[49m";
            else std::cout << "\033[48;2;" << r << ";" << g << ";" << b << "m";
            settings[3] = r; settings[4] = g; settings[5] = b;
        }
#ifdef _WIN32
        else if (winConsoleColorsEnabled) {
            // Windows Console API handles background colors differently
            // We'll need to combine foreground and background
            CONSOLE_SCREEN_BUFFER_INFO csbi;
            if (GetConsoleScreenBufferInfo(hConsole, &csbi)) {
                WORD currentFg = csbi.wAttributes & 0x0F;
                // Simple mapping for background colors
                WORD bgColor = 0;
                if (!(r == -1 || g == -1 || b == -1)) {
                    // Basic background color detection (simplified)
                    if (r > 200 && g < 50 && b < 50) bgColor = BACKGROUND_RED;
                    else if (r < 50 && g > 200 && b < 50) bgColor = BACKGROUND_GREEN;
                    else if (r > 200 && g > 200 && b < 50) bgColor = BACKGROUND_RED | BACKGROUND_GREEN;
                    else if (r < 50 && g < 50 && b > 200) bgColor = BACKGROUND_BLUE;
                    else if (r > 200 && g < 50 && b > 200) bgColor = BACKGROUND_RED | BACKGROUND_BLUE;
                    else if (r < 50 && g > 200 && b > 200) bgColor = BACKGROUND_GREEN | BACKGROUND_BLUE;
                    else if (r > 200 && g > 200 && b > 200) bgColor = BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE;
                    else bgColor = 0;
                }
                SetConsoleTextAttribute(hConsole, currentFg | bgColor);
            }
        }
#endif
    }
    
    void setBackgroundColor(color color) {
        if (supportsAnsi) {
            int index = static_cast<int>(color);
            if (index >= 0 && index < 17) {
                setBackgroundColor(rgbansi[index][0], rgbansi[index][1], rgbansi[index][2]);
            }
        }
#ifdef _WIN32
        else if (winConsoleColorsEnabled) {
            // Map our color enum to Windows console background colors
            static const WORD winBgColorMap[17] = {
                0,                     // BLACK
                BACKGROUND_RED,        // RED
                BACKGROUND_GREEN,      // GREEN
                BACKGROUND_RED | BACKGROUND_GREEN, // YELLOW
                BACKGROUND_BLUE,       // BLUE
                BACKGROUND_RED | BACKGROUND_BLUE,  // MAGENTA
                BACKGROUND_GREEN | BACKGROUND_BLUE, // CYAN
                BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE, // WHITE
                BACKGROUND_INTENSITY,  // GRAY
                BACKGROUND_RED | BACKGROUND_INTENSITY,        // BRIGHT_RED
                BACKGROUND_GREEN | BACKGROUND_INTENSITY,      // BRIGHT_GREEN
                BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_INTENSITY, // BRIGHT_YELLOW
                BACKGROUND_BLUE | BACKGROUND_INTENSITY,       // BRIGHT_BLUE
                BACKGROUND_RED | BACKGROUND_BLUE | BACKGROUND_INTENSITY,  // BRIGHT_MAGENTA
                BACKGROUND_GREEN | BACKGROUND_BLUE | BACKGROUND_INTENSITY, // BRIGHT_CYAN
                BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE | BACKGROUND_INTENSITY, // BRIGHT_WHITE
                0                      // RESET_COLOR
            };
            
            int index = static_cast<int>(color);
            if (index >= 0 && index < 17) {
                CONSOLE_SCREEN_BUFFER_INFO csbi;
                if (GetConsoleScreenBufferInfo(hConsole, &csbi)) {
                    WORD currentFg = csbi.wAttributes & 0x0F;
                    SetConsoleTextAttribute(hConsole, currentFg | winBgColorMap[index]);
                }
            }
        }
#endif
    }
    
    void setAttribute(attributes attb) {
        if (supportsAnsi) {
            std::cout << "\033[" << static_cast<int>(attb) << "m";
        }
        // Windows Console API doesn't support most attributes directly
    }
    
    void setColor(color fg, color bg) {
        setBackgroundColor(bg);
        setForegroundColor(fg);
    }
    
    void setColor(int r, int g, int b, color bg) {
        setBackgroundColor(bg);
        setForegroundColor(r, g, b);
    }
    
    void setColor(color fg, int r, int g, int b) {
        setBackgroundColor(r, g, b);
        setForegroundColor(fg);
    }
    
    void setColor(int r, int g, int b, int r1, int g1, int b1) {
        setForegroundColor(r, g, b);
        setBackgroundColor(r1, g1, b1);
    }
    
    void reset() {
        if (supportsAnsi) {
            std::cout << "\033[0m";
            for(int i = 0; i < 6; i++) settings[i] = -1;
        }
#ifdef _WIN32
        else if (winConsoleColorsEnabled) {
            resetWinConsoleColor();
        }
#endif
    }
    
    void reset_attributes() {
        if (supportsAnsi) {
            std::cout << "\033[0m";
            setColor(settings[0], settings[1], settings[2], 
                    settings[3], settings[4], settings[5]);
        }
#ifdef _WIN32
        else if (winConsoleColorsEnabled) {
            resetWinConsoleColor();
        }
#endif
    }
    
    void reset_fg_color() {
        if (supportsAnsi) {
            std::cout << "\033[39m";
            for(int i = 0; i < 3; i++) settings[i] = -1;
        }
#ifdef _WIN32
        else if (winConsoleColorsEnabled) {
            CONSOLE_SCREEN_BUFFER_INFO csbi;
            if (GetConsoleScreenBufferInfo(hConsole, &csbi)) {
                WORD currentBg = csbi.wAttributes & 0xF0;
                SetConsoleTextAttribute(hConsole, winConsoleDefaultAttributes & 0x0F | currentBg);
            }
        }
#endif
    }
    
    void reset_bg_color() {
        if (supportsAnsi) {
            std::cout << "\033[49m";
            for(int i = 3; i < 6; i++) settings[i] = -1;
        }
#ifdef _WIN32
        else if (winConsoleColorsEnabled) {
            CONSOLE_SCREEN_BUFFER_INFO csbi;
            if (GetConsoleScreenBufferInfo(hConsole, &csbi)) {
                WORD currentFg = csbi.wAttributes & 0x0F;
                SetConsoleTextAttribute(hConsole, currentFg | (winConsoleDefaultAttributes & 0xF0));
            }
        }
#endif
    }
    
    void reset_colors() {
        reset_fg_color(); 
        reset_bg_color();
    }
    
    void print(const char* format, ...) {
        va_list args;
        va_start(args, format);
        vprintf(format, args);
        va_end(args);
    }
    
    template <class T>
    DualSupportOutput& operator<<(T info) {
        std::cout << info;
        return *this;
    }
    
    DualSupportOutput& operator<<(std::ostream& (*manip)(std::ostream&)) {
        manip(std::cout);
        return *this;
    }
    
    void flush() {
        std::cout.flush();
    }
    
    void endl() {
        std::cout << std::endl;
    }
    
    template<class T>
    void printline(T arg) {
        std::cout << arg; 
        if (supportsAnsi) std::cout << "\033[39;49m";
#ifdef _WIN32
        else if (winConsoleColorsEnabled) {
            resetWinConsoleColor();
        }
#endif
        endl();
        setColor(settings[0], settings[1], settings[2], 
                settings[3], settings[4], settings[5]);
    }
};

// Global instance
static DualSupportOutput advout;

// Utility functions
inline void wait_until_enter() {
    std::string s;
    std::getline(std::cin, s);
}

inline void wait_ms(unsigned int t) {
    if (t <= 0) return;
#ifdef _WIN32
    Sleep(t); 
#else
    usleep(t * 1000);
#endif
}

inline void wait_s(unsigned int t) {
    wait_ms(t * 1000);
}

inline void wait_min(unsigned int t) {
    wait_ms(t * 60000);
}

} // namespace adv

#endif // ADVOUT_HPP