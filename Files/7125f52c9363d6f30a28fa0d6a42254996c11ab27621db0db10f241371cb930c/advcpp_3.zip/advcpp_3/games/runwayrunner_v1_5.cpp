#include "../advio.hpp"
#include <cstdlib>
#include <ctime>
#include <string>
#include <vector>
#include <deque>
#include <algorithm>
#include <chrono>
#include <sstream>
#include <iomanip>

using namespace adv;

// Game constants
const int VIEW_WIDTH = 32;
const int PLAYER_POS = 4;
const int CHECKPOINT_DIST = 512;
const int SAFE_ZONE = 4;
const int BASE_GOAL = 512;
const int FPS_MS = 100;
const int MAX_HEALTH = 100;

// Tile types
enum TileType {
    TILE_AIR = 0,
    TILE_WALL = 1,
    TILE_COIN = 2,
    TILE_TOTEM = 3,
    TILE_CANNON = 4,
    TILE_COINX2 = 5,
    TILE_SKIPPER = 6,
    TILE_THIEF = 7,
    TILE_LANETP = 8,
    TILE_CHECKPOINT = 10
};

struct Tile {
    TileType type;
};

struct Lane {
    std::deque<Tile> tiles;
    int y;
};

// Game state
int playerLane = 1;
int playerCoins = 0;
int playerTotems = 0;
int playerCannons = 0;
int playerHealth = MAX_HEALTH;
int checkpointCount = 0;
int nextCheckpoint = CHECKPOINT_DIST;
int goalCoins = BASE_GOAL;
long long gameSeed = 0;
std::vector<Lane> lanes;
bool gameOver = false;
bool paused = false;
bool skipMode = false;
int skipCounter = 0;
int coinMultiplier = 1;
int coinMultiplierTime = 0;
int invincibleTime = 0;
int worldX = 0;

long long splitMix64(long long& state) {
    long long result = (state += 0x9E3779B97F4A7C15LL);
    result = (result ^ (result >> 30)) * 0xBF58476D1CE4E5B9LL;
    result = (result ^ (result >> 27)) * 0x94D049BB133111EBLL;
    return result ^ (result >> 31);
}

int randomInt(long long& state, int min, int max) {
    return min + (splitMix64(state) % (max - min + 1));
}

TileType generateTile(long long& seed, bool inSafeZone = false) {
    if (inSafeZone) return TILE_AIR;
    
    int r = randomInt(seed, 1, 100);
    
    if (r <= 25) return TILE_AIR;
    else if (r <= 65) return TILE_WALL;
    else if (r <= 85) return TILE_COIN;
    else if (r <= 95) {
        int benefit = randomInt(seed, 0, 3);
        if (benefit == 0) return TILE_TOTEM;
        else if (benefit == 1) return TILE_CANNON;
        else if (benefit == 2) return TILE_COINX2;
        else return TILE_SKIPPER;
    } else {
        int disaster = randomInt(seed, 0, 1);
        if (disaster == 0) return TILE_THIEF;
        else return TILE_LANETP;
    }
}

void ensurePassable(std::vector<TileType>& column, long long& seed) {
    int wallCount = 0;
    for (int i = 0; i < 3; i++) {
        if (column[i] == TILE_WALL) wallCount++;
    }
    
    if (wallCount > 1) {
        for (int i = 0; i < 3 && wallCount > 1; i++) {
            if (column[i] == TILE_WALL) {
                column[i] = TILE_AIR;
                wallCount--;
            }
        }
    }
    
    bool hasValidSpot = false;
    for (int i = 0; i < 3; i++) {
        if (column[i] != TILE_WALL) {
            hasValidSpot = true;
            break;
        }
    }
    
    if (!hasValidSpot) {
        column[1] = TILE_AIR;
    }
}

void generateColumn(int worldPos) {
    bool isCheckpoint = (worldPos == nextCheckpoint);
    
    bool inSafeZone = false;
    if (checkpointCount > 0) {
        int lastCheckpoint = checkpointCount * CHECKPOINT_DIST;
        if (worldPos > lastCheckpoint && worldPos - lastCheckpoint < SAFE_ZONE) {
            inSafeZone = true;
        }
    }
    
    std::vector<TileType> column(3);
    
    for (int lane = 0; lane < 3; lane++) {
        column[lane] = generateTile(gameSeed, inSafeZone);
    }
    
    if (isCheckpoint) {
        column[0] = TILE_CHECKPOINT;
        column[1] = TILE_CHECKPOINT;
        column[2] = TILE_CHECKPOINT;
        checkpointCount++;
        nextCheckpoint += CHECKPOINT_DIST;
    } else {
        ensurePassable(column, gameSeed);
    }
    
    for (int lane = 0; lane < 3; lane++) {
        Tile t;
        t.type = column[lane];
        lanes[lane].tiles.push_back(t);
    }
}

void interactWithTile(TileType tile) {
    switch(tile) {
        case TILE_COIN:
            playerCoins += 1 * coinMultiplier;
            break;
        case TILE_TOTEM:
            playerTotems++;
            break;
        case TILE_CANNON:
            playerCannons++;
            break;
        case TILE_COINX2:
            coinMultiplier = 2;
            coinMultiplierTime = 50;
            break;
        case TILE_SKIPPER:
            skipMode = true;
            skipCounter = 10;
            break;
        case TILE_THIEF:
            if (invincibleTime <= 0 && playerTotems == 0) {
                playerCoins /= 2;
                playerHealth -= 10;
                invincibleTime = 30;
            } else if (playerTotems > 0) {
                playerTotems--;
                invincibleTime = 60;
            }
            break;
        case TILE_LANETP:
            {
                int newLane = randomInt(gameSeed, 0, 2);
                while (newLane == playerLane) {
                    newLane = randomInt(gameSeed, 0, 2);
                }
                playerLane = newLane;
            }
            break;
        default:
            break;
    }
    
    if (playerHealth <= 0) {
        gameOver = true;
    }
    if (playerHealth > MAX_HEALTH) playerHealth = MAX_HEALTH;
}

void movePlayer(int newLane) {
    if (skipMode) {
        skipCounter--;
        if (skipCounter <= 0) skipMode = false;
        return;
    }
    
    if (newLane < 0) newLane = 0;
    if (newLane > 2) newLane = 2;
    
    int futureX = PLAYER_POS;
    if (futureX >= (int)lanes[newLane].tiles.size()) {
        return;
    }
    
    TileType targetTile = lanes[newLane].tiles[futureX].type;
    
    if (targetTile == TILE_WALL) {
        if (invincibleTime > 0) {
            lanes[newLane].tiles[futureX].type = TILE_AIR;
            playerLane = newLane;
        } else if (playerCannons > 0) {
            playerCannons--;
            lanes[newLane].tiles[futureX].type = TILE_AIR;
            playerLane = newLane;
        } else {
            playerHealth -= 20;
            if (playerHealth <= 0) gameOver = true;
        }
    } else {
        playerLane = newLane;
        interactWithTile(targetTile);
        lanes[playerLane].tiles[futureX].type = TILE_AIR;
    }
}

void updateTimers() {
    if (coinMultiplierTime > 0) {
        coinMultiplierTime--;
        if (coinMultiplierTime == 0) coinMultiplier = 1;
    }
    
    if (invincibleTime > 0) {
        invincibleTime--;
    }
}

void drawGame() {
    advcsr.clear();
    advcsr.gotoxy(0, 0);
    
    std::string title = "|--- Play - Runway Runner 1.5 ";
    if (paused) {
        title += "[PAUSED] ";
    }
    title += "-------------------------------------|";
    advout.setForegroundColor(YELLOW);
    advout.printline(title);
    advout.reset();
    
    for (int lane = 0; lane < 3; lane++) {
        advout << "| ";
        
        for (int x = 0; x < VIEW_WIDTH; x++) {
            if (x >= (int)lanes[lane].tiles.size()) {
                advout << "  ";
                continue;
            }
            
            TileType tile = lanes[lane].tiles[x].type;
            
            if (lane == playerLane && x == PLAYER_POS && !skipMode && !gameOver) {
                advout.setForegroundColor(GREEN);
                advout << "[]";
                advout.reset();
            } else {
                switch(tile) {
                    case TILE_WALL:
                        advout.setForegroundColor(RED);
                        advout << "##";
                        break;
                    case TILE_COIN:
                        advout.setForegroundColor(YELLOW);
                        advout << "$$";
                        break;
                    case TILE_TOTEM:
                        advout.setForegroundColor(MAGENTA);
                        advout << "TT";
                        break;
                    case TILE_CANNON:
                        advout.setForegroundColor(CYAN);
                        advout << "C=";
                        break;
                    case TILE_COINX2:
                        advout.setForegroundColor(YELLOW);
                        advout << "x2";
                        break;
                    case TILE_SKIPPER:
                        advout.setForegroundColor(CYAN);
                        advout << ">>";
                        break;
                    case TILE_THIEF:
                        advout.setForegroundColor(RED);
                        advout << "()";
                        break;
                    case TILE_LANETP:
                        advout.setForegroundColor(MAGENTA);
                        advout << "~~";
                        break;
                    case TILE_CHECKPOINT:
                        advout.setForegroundColor(GREEN);
                        advout << "||";
                        break;
                    default:
                        advout << "  ";
                        break;
                }
                advout.reset();
            }
        }
        
        advout << " |\n";
    }
    
    advout.setForegroundColor(YELLOW);
    advout.printline("|------------------------------------------------------------------|");
    advout.reset();
    
    std::stringstream status;
    status << "| coins: " << std::setw(4) << std::setfill('0') << playerCoins 
           << " | goal: " << std::setw(4) << std::setfill('0') << goalCoins
           << " | totems: " << std::setw(2) << std::setfill('0') << playerTotems 
           << " | cannons: " << std::setw(2) << std::setfill('0') << playerCannons
           << " | HP: " << std::setw(3) << std::setfill('0') << playerHealth << "/" << MAX_HEALTH;
    
    if (coinMultiplier > 1) {
        status << " | x2";
    }
    
    status << " | [W/S] move |";
    
    std::string statusStr = status.str();
    int padding = 66 - statusStr.length();
    if (padding > 0) {
        statusStr += std::string(padding, ' ');
    }
    
    advout << statusStr << "\n";
    
    advout.setForegroundColor(YELLOW);
    advout.printline("|------------------------------------------------------------------|");
    advout.reset();
    
    advout.flush();
}

void initGame(long long seed) {
    gameSeed = seed;
    playerLane = 1;
    playerCoins = 0;
    playerTotems = 0;
    playerCannons = 0;
    playerHealth = MAX_HEALTH;
    checkpointCount = 0;
    nextCheckpoint = CHECKPOINT_DIST;
    goalCoins = BASE_GOAL;
    gameOver = false;
    paused = false;
    skipMode = false;
    skipCounter = 0;
    coinMultiplier = 1;
    coinMultiplierTime = 0;
    invincibleTime = 0;
    worldX = 0;
    
    lanes.clear();
    for (int i = 0; i < 3; i++) {
        Lane lane;
        lane.y = i;
        lanes.push_back(lane);
    }
    
    for (int x = 0; x < VIEW_WIDTH + 20; x++) {
        generateColumn(x);
    }
}

void showGameOver() {
    advcsr.clear();
    advout.setForegroundColor(RED);
    advout.printline("\n\n");
    advout.printline("        +============================+");
    advout.printline("        |         GAME OVER          |");
    advout.printline("        +============================+");
    advout.printline("        |                            |");
    advout.printline("        |    You have been defeated! |");
    advout.printline("        |                            |");
    advout.printline("        |    Coins: " + std::to_string(playerCoins) + "                    |");
    advout.printline("        |    Checkpoints: " + std::to_string(checkpointCount) + "                |");
    advout.printline("        |    Seed: " + std::to_string(gameSeed) + "              |");
    advout.printline("        |                            |");
    advout.printline("        |    Press R to restart      |");
    advout.printline("        |    Press Q to quit         |");
    advout.printline("        |                            |");
    advout.printline("        +============================+");
    advout.reset();
    advout.flush();
}

int main() {
    advcsr.hide();
    
    while (true) {
        advcsr.clear();
        advout.setForegroundColor(YELLOW);
        advout.printline("|--- Runway Runner 1.5 -----------------------------------------|");
        advout.reset();
        advout.printline("|                                                                  |");
        advout.printline("|  Enter seed (number) or press Enter for random:                   |");
        advout.printline("|                                                                  |");
        advout.setForegroundColor(CYAN);
        advout.print("| >>> ");
        advout.reset();
        advout.flush();
        
        std::string seedInput;
        std::getline(std::cin, seedInput);
        
        long long seed;
        if (seedInput.empty()) {
            seed = std::chrono::steady_clock::now().time_since_epoch().count();
        } else {
            seed = std::stoll(seedInput);
        }
        
        initGame(seed);
        
        auto lastFrame = std::chrono::steady_clock::now();
        
        while (!gameOver) {
            auto now = std::chrono::steady_clock::now();
            auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastFrame).count();
            
            if (elapsed >= FPS_MS && !paused) {
                lastFrame = now;
                
                worldX++;
                
                for (int lane = 0; lane < 3; lane++) {
                    if (!lanes[lane].tiles.empty()) {
                        lanes[lane].tiles.pop_front();
                    }
                }
                
                generateColumn(worldX + VIEW_WIDTH);
                
                if (!skipMode && !gameOver) {
                    updateTimers();
                    
                    if (lanes[playerLane].tiles.size() > PLAYER_POS) {
                        TileType currentTile = lanes[playerLane].tiles[PLAYER_POS].type;
                        if (currentTile != TILE_AIR) {
                            if (currentTile == TILE_WALL) {
                                if (invincibleTime > 0) {
                                    lanes[playerLane].tiles[PLAYER_POS].type = TILE_AIR;
                                } else if (playerCannons > 0) {
                                    playerCannons--;
                                    lanes[playerLane].tiles[PLAYER_POS].type = TILE_AIR;
                                } else {
                                    playerHealth -= 20;
                                    if (playerHealth <= 0) gameOver = true;
                                }
                            } else {
                                interactWithTile(currentTile);
                                lanes[playerLane].tiles[PLAYER_POS].type = TILE_AIR;
                            }
                        }
                    }
                } else if (skipMode) {
                    skipCounter--;
                    if (skipCounter <= 0) skipMode = false;
                }
                
                drawGame();
                
                if (playerCoins >= goalCoins) {
                    goalCoins += BASE_GOAL;
                    playerHealth = MAX_HEALTH;
                    drawGame();
                    advout.setForegroundColor(YELLOW);
                    advout.printline("\n\n        +============================+");
                    advout.printline("        |      CHECKPOINT REACHED!    |");
                    advout.printline("        +============================+");
                    advout.printline("        |    Health restored!         |");
                    advout.printline("        |    New goal: " + std::to_string(goalCoins) + " coins    |");
                    advout.printline("        +============================+");
                    advout.reset();
                    advout.flush();
                    wait_s(2);
                }
            }
            
            if (advin.wait_press_char()) {
                char key = advin.wait_press_char();
                
                switch(key) {
                    case 'w':
                    case 'W':
                        movePlayer(playerLane - 1);
                        drawGame();
                        break;
                    case 's':
                    case 'S':
                        movePlayer(playerLane + 1);
                        drawGame();
                        break;
                    case 'p':
                    case 'P':
                        paused = !paused;
                        drawGame();
                        break;
                    default:
                        break;
                }
            }
            
            wait_ms(10);
        }
        
        showGameOver();
        
        while (true) {
            char gameOverKey = advin.wait_press_char();
            if (gameOverKey == 'r' || gameOverKey == 'R') {
                break;
            } else if (gameOverKey == 'q' || gameOverKey == 'Q') {
                advcsr.show();
                return 0;
            }
        }
    }
    
    advcsr.show();
    return 0;
}