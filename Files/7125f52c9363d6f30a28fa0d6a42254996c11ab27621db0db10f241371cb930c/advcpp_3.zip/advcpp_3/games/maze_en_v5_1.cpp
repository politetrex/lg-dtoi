#include "../advio.hpp"
#include <ctime>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <chrono>
#include <sstream>
#include <iomanip>

#ifdef _WIN32
#include <conio.h>
#else
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#endif

using namespace adv;

const int level_n[] = {10, 25, 30, 40};
const int level_m[] = {10, 20, 30, 30};
const int dx[] = {0, 1, 0, -1};
const int dy[] = {1, 0, -1, 0};
short f[100][100];
int x, y, val, flag, current_level, wait_time, cnt_boom = 3;
int n, m, fx, fy, macnt;
char name[16];
char k;
int nx, ny;
time_t start, now;
bool is_win = 1;
bool lastSpacePressed = false;

// Simple pad function that works
std::string pad(const std::string& s, int width) {
    if ((int)s.length() >= width) return s.substr(0, width);
    return s + std::string(width - s.length(), ' ');
}

// Helper to create bordered lines
std::string makeLine(const std::string& content) {
    return "|" + pad(content, 73) + "|";
}

bool keyPressed() {
#ifdef _WIN32
    return _kbhit() != 0;
#else
    struct termios oldt, newt;
    int ch;
    int oldf;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);
    if(ch != EOF) {
        ungetc(ch, stdin);
        return true;
    }
    return false;
#endif
}

char getKey() {
#ifdef _WIN32
    return _getch();
#else
    return getchar();
#endif
}

bool nb(int x, int y) {
    if(x < 1 || x > n-2 || y < 1 || y > m-2 || f[x][y] != 1) return 0;
    int hmz = 0;
    if(f[x+1][y] != 1) hmz++;
    if(f[x][y+1] != 1) hmz++;
    if(f[x-1][y] != 1) hmz++;
    if(f[x][y-1] != 1) hmz++;
    if(hmz != 1 || rand() % 10 == 0) return 0;
    return 1;
}

void dfs(int x, int y, int cnt) {
    if(cnt > macnt) {
        macnt = cnt;
        fx = x;
        fy = y;
    }
    if(rand() % 10 < 1) f[x][y] = 2;
    else f[x][y] = 0;
    int z = rand() % 4, s = 0;
    
    if(z == 0 && nb(x+1, y)) dfs(x+1, y, cnt+1), s++;
    else if(z < 2 && nb(x, y+1)) dfs(x, y+1, cnt+1), s++;
    else if(z < 3 && nb(x-1, y)) dfs(x-1, y, cnt+1), s++;
    else if(nb(x, y-1)) dfs(x, y-1, cnt+1), s++;
    if(s == 0) {
        if(nb(x+1, y)) dfs(x+1, y, cnt+1);
        if(nb(x, y+1)) dfs(x, y+1, cnt+1);
        if(nb(x-1, y)) dfs(x-1, y, cnt+1);
        if(nb(x, y-1)) dfs(x, y-1, cnt+1);
    } else {
        if(nb(x+1, y) && rand() % 5 == 0) dfs(x+1, y, cnt+1);
        if(nb(x, y+1) && rand() % 5 == 0) dfs(x, y+1, cnt+1);
        if(nb(x-1, y) && rand() % 5 == 0) dfs(x-1, y, cnt+1);
        if(nb(x, y-1) && rand() % 5 == 0) dfs(x, y-1, cnt+1);
    }
}

void Build() {
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            f[i][j] = 1;
    
    f[1][1] = 0;
    macnt = 0;
    dfs(1, 2, 1);
    for(int i = 1; i < n-1; i++)
        for(int j = 1; j < m-1; j++)
            if(nb(i, j)) dfs(i, j, 1);
    f[fx][fy] = 0;
}

void First_Step() {
    advcsr.clear();
    advout.setForegroundColor(YELLOW);
    advout.printline("+=========================================================================+");
    advout.printline("|                         MAZE RUNNER - DIAMOND HEIST                     |");
    advout.printline("+=========================================================================+");
    advout.printline(makeLine(""));
    advout.printline(makeLine(" Welcome, Operative. Your mission awaits."));
    advout.printline(makeLine(""));
    advout.printline(makeLine(" Enter your code name (max 15 characters):"));
    advout.printline(makeLine(""));
    advout.printline("+=========================================================================+");
    advout.reset();
    advout << "\n  >>> ";
    advout.flush();
    std::cin.getline(name, 16);
    
    advcsr.clear();
    advout.setForegroundColor(YELLOW);
    advout.printline("+=========================================================================+");
    advout.printline("|                         MAZE RUNNER - DIAMOND HEIST                     |");
    advout.printline("+=========================================================================+");
    advout.printline(makeLine(""));
    advout.printline(makeLine(" Good luck, " + std::string(name) + "."));
    advout.printline(makeLine(""));
    advout.printline(makeLine(" Press any key to begin your training."));
    advout.printline(makeLine(""));
    advout.printline("+=========================================================================+");
    advout.reset();
    advout.flush();
    getKey();
    advcsr.clear();
}

void Loading() {
    advcsr.clear();
    advout.setForegroundColor(CYAN);
    advout.printline("+=========================================================================+");
    advout.printline("|                         MAZE RUNNER - DIAMOND HEIST                     |");
    advout.printline("+=========================================================================+");
    advout.printline(makeLine(""));
    advout.printline(makeLine(" LOADING MISSION DATA..."));
    advout.printline(makeLine(""));
    advout.printline(makeLine(" Operative, your action window is extremely limited."));
    advout.printline(makeLine(""));
    advout.printline(makeLine(" You have only " + std::to_string(n*m) + " seconds before the maze collapses."));
    advout.printline(makeLine(""));
    advout.printline(makeLine(" Extract as many diamonds as possible. They are vital."));
    advout.printline(makeLine(""));
    advout.printline(makeLine(" Good luck."));
    advout.printline(makeLine(""));
    advout.printline("+=========================================================================+");
    advout.reset();
    advout.flush();
    wait_s(3);
    advcsr.clear();
}

void Welcome() {
    advcsr.hide();
    advcsr.clear();
    advout.setForegroundColor(YELLOW);
    advout.printline("+=========================================================================+");
    advout.printline("|                         MAZE RUNNER - DIAMOND HEIST                     |");
    advout.printline("+=========================================================================+");
    advout.printline(makeLine(""));
    advout.printline(makeLine(" Calling operative " + std::string(name) + "..."));
    advout.printline(makeLine(""));
    advout.printline(makeLine(" Headquarters reports an emergency mission."));
    advout.printline(makeLine(""));
    advout.printline(makeLine(" Move immediately!"));
    advout.printline(makeLine(""));
    advout.printline(makeLine(" " + std::string(name) + " standing by."));
    advout.printline(makeLine(""));
    advout.printline(makeLine(" Press any key to proceed to the extraction zone."));
    advout.printline(makeLine(""));
    advout.printline("+=========================================================================+");
    advout.reset();
    advout.flush();
    getKey();
    advcsr.clear();
    
    n = level_n[current_level];
    m = level_m[current_level];
    wait_time = n * m;
    
    Build();
    advcsr.clear();
    Loading();
}

void print() {
    advcsr.clear();
    
    advout.setForegroundColor(YELLOW);
    advout.printline("+=========================================================================+");
    advout.printline("|                         MAZE RUNNER - DIAMOND HEIST                     |");
    advout.printline("+=========================================================================+");
    advout.reset();
    
    const int viewHeight = 15;
    const int viewWidth = 35;
    
    int startX = std::max(1, x - viewHeight/2);
    int endX = std::min(n - 1, startX + viewHeight - 1);
    int startY = std::max(1, y - viewWidth/2);
    int endY = std::min(m - 1, startY + viewWidth - 1);
    
    if(endX - startX + 1 < viewHeight && startX > 1) {
        startX = std::max(1, endX - viewHeight + 1);
    }
    if(endY - startY + 1 < viewWidth && startY > 1) {
        startY = std::max(1, endY - viewWidth + 1);
    }
    endX = std::min(n - 1, startX + viewHeight - 1);
    endY = std::min(m - 1, startY + viewWidth - 1);
    
    for(int i = startX; i <= endX; i++) {
        advout << "| ";
        
        for(int j = startY; j <= endY; j++) {
            if(i == fx && j == fy) {
                advout.setForegroundColor(RED);
                advout << "R";
            } else if(i == x && j == y) {
                advout.setForegroundColor(GREEN);
                advout << "O";
            } else {
                if(f[i][j] == 1) {
                    advout.setForegroundColor(YELLOW);
                    advout << "#";
                } else if(f[i][j] == 2) {
                    advout.setForegroundColor(CYAN);
                    advout << "$";
                } else {
                    advout << " ";
                }
            }
            advout.reset();
            advout << " ";
        }
        
        int drawnCols = endY - startY +1;
        for(int j = drawnCols; j <= viewWidth; j++) {
            advout << "  ";
        }
        
        advout << "|\n";
    }
    
    int drawnRows = endX - startX + 1;
    for(int i = drawnRows; i < viewHeight; i++) {
        advout << "| ";
        for(int j = 0; j <= viewWidth; j++) {
            advout << "  ";
        }
        advout << "|\n";
    }
    
    advout.setForegroundColor(YELLOW);
    advout.printline("+=========================================================================+");
    advout.reset();
    
    int timeLeft = (int)(wait_time - (time(nullptr) - start));
    if(timeLeft < 0) timeLeft = 0;
    
    std::string cannonStr;
    for(int i = 1; i <= cnt_boom; i++) cannonStr += "|";
    for(int i = cnt_boom + 1; i <= 3; i++) cannonStr += " ";
    
    std::ostringstream statusLine;
    statusLine << "  Level: " << (current_level + 1) << "/4  |  Diamonds: " << val << "  |  Cannon: " << cannonStr << "  |  Time: " << timeLeft << "s left  ";
    advout.printline(makeLine(statusLine.str()));
    
    advout.setForegroundColor(YELLOW);
    advout.printline("+=========================================================================+");
    advout.printline("|  [W] Up  [S] Down  [A] Left  [D] Right  [SPACE] Cannon  [R] Get Cannon  |");
    advout.printline("+=========================================================================+");
    advout.reset();
    advout.flush();
}

void Ending(bool win) {
    advcsr.clear();
    if(win) {
        advout.setForegroundColor(YELLOW);
        advout.printline("+=========================================================================+");
        advout.printline("|                         MISSION ACCOMPLISHED!                           |");
        advout.printline("+=========================================================================+");
        advout.printline(makeLine(""));
        advout.printline(makeLine(" Quick! Grab the extraction rope!"));
        advout.printline(makeLine(""));
        advout.printline("+=========================================================================+");
        advout.reset();
        advout.flush();
        wait_s(2);
        advcsr.clear();
        
        advout.setForegroundColor(GREEN);
        advout.printline("+=========================================================================+");
        advout.printline("|                            MISSION SUCCESS                              |");
        advout.printline("+=========================================================================+");
        advout.printline(makeLine(""));
        advout.printline(makeLine(" You've recovered " + std::to_string(val) + " diamonds, operative!"));
        advout.printline(makeLine(""));
        advout.printline(makeLine(" The research team sends their gratitude."));
        advout.printline(makeLine(""));
        advout.printline(makeLine(" Take some well-deserved rest, " + std::string(name) + "."));
        advout.printline(makeLine(""));
        advout.printline("+=========================================================================+");
        advout.reset();
        advout.flush();
        wait_s(4);
        advcsr.clear();
    } else {
        advout.setForegroundColor(RED);
        advout.printline("+=========================================================================+");
        advout.printline("|                          MISSION FAILURE                               |");
        advout.printline("+=========================================================================+");
        advout.printline(makeLine(""));
        advout.printline(makeLine(" " + std::string(name) + "! Respond, operative " + std::string(name) + "!"));
        advout.printline(makeLine(""));
        advout.printline(makeLine(" " + std::string(name) + ", KIA in operation " + std::to_string(current_level + 1) + "."));
        advout.printline(makeLine(""));
        advout.printline("+=========================================================================+");
        advout.reset();
        advout.flush();
        wait_s(5);
    }
}

void W() {
    if(x > 1 && f[x - 1][y] != 1) {
        x--;
        flag = 4;
    }
}

void S() {
    if(x < n-1 && f[x + 1][y] != 1) {
        x++;
        flag = 2;
    }
}

void A() {
    if(y > 1 && f[x][y - 1] != 1) {
        y--;
        flag = 3;
    }
}

void D() {
    if(y < m-1 && f[x][y + 1] != 1) {
        y++;
        flag = 1;
    }
}

void Break_wall() {
    if(cnt_boom == 0) {
        advout.setForegroundColor(RED);
        advout.printline("\n\n    [NO CANNON CHARGES!]");
        advout.reset();
        wait_s(1);
        print();
        return;
    }
    
    cnt_boom--;
    nx = x, ny = y;
    
    advout.setForegroundColor(GREEN);
    advout.printline("\n\n    [CANNON FIRED]");
    advout.flush();
    
    bool destroyed = false;
    while(nx > 0 && nx < n-1 && ny > 0 && ny < m-1) {
        nx += dx[flag-1];
        ny += dy[flag-1];
        
        if(f[nx][ny] == 1 || f[nx][ny] == 2) {
            f[nx][ny] = 0;
            destroyed = true;
            break;
        }
    }
    
    if(destroyed) {
        advout.setForegroundColor(GREEN);
        advout.printline("    [TARGET DESTROYED!]");
    } else {
        advout.setForegroundColor(YELLOW);
        advout.printline("    [NOTHING IN RANGE]");
    }
    advout.reset();
    wait_s(1);
    print();
}

void Get_Boom() {
    if(val < 2) {
        advout.setForegroundColor(RED);
        advout.printline("\n\n    [NOT ENOUGH DIAMONDS! Need 2]");
        advout.reset();
        wait_s(1);
        print();
        return;
    }
    if(cnt_boom >= 3) {
        advout.setForegroundColor(YELLOW);
        advout.printline("\n\n    [CANNON ALREADY FULL!]");
        advout.reset();
        wait_s(1);
        print();
        return;
    }
    val -= 2;
    cnt_boom++;
    advout.setForegroundColor(GREEN);
    advout.printline("\n\n    [CANNON CHARGE ACQUIRED!]");
    advout.reset();
    wait_s(1);
    print();
}

void THEEND(bool win) {
    advcsr.clear();
    if(win) {
        advout.setForegroundColor(YELLOW);
        advout.printline("+=========================================================================+");
        advout.printline("|                          MISSION COMPLETE                               |");
        advout.printline("+=========================================================================+");
        advout.printline(makeLine(""));
        advout.printline(makeLine(" Operative " + std::string(name) + ", report to debriefing."));
        advout.printline(makeLine(""));
        advout.printline(makeLine(" What's wrong?"));
        advout.printline(makeLine(""));
        advout.printline("+=========================================================================+");
        advout.reset();
        advout.flush();
        wait_s(2);
        advcsr.clear();
        
        advout.setForegroundColor(RED);
        advout.printline("+=========================================================================+");
        advout.printline("|                               BANG!!!                                   |");
        advout.printline("+=========================================================================+");
        advout.printline(makeLine(""));
        advout.printline(makeLine(" You! *cough*... you actually..."));
        advout.printline(makeLine(""));
        advout.printline("+=========================================================================+");
        advout.reset();
        advout.flush();
        wait_s(3);
        advcsr.clear();
        
        advout.setForegroundColor(CYAN);
        advout.printline("+=========================================================================+");
        advout.printline("|                         THANK YOU, OPERATIVE                            |");
        advout.printline("+=========================================================================+");
        advout.printline(makeLine(""));
        advout.printline(makeLine(" See you in another life, " + std::string(name) + "."));
        advout.printline(makeLine(""));
        advout.printline(makeLine(" " + std::string(name) + ", KIA."));
        advout.printline(makeLine(""));
        advout.printline("+=========================================================================+");
        advout.reset();
        advout.flush();
        wait_s(5);
    } else {
        advout.setForegroundColor(RED);
        advout.printline("+=========================================================================+");
        advout.printline("|                          GAME OVER - FAILURE                            |");
        advout.printline("+=========================================================================+");
        advout.printline(makeLine(""));
        advout.printline(makeLine(" Operative " + std::string(name) + " did not return."));
        advout.printline(makeLine(""));
        advout.printline(makeLine(" Mission Status: LOST"));
        advout.printline(makeLine(""));
        advout.printline("+=========================================================================+");
        advout.reset();
        advout.flush();
        wait_s(4);
    }
}

int main() {
    srand((unsigned int)time(nullptr));
    First_Step();
    is_win = true;
    current_level = 0;
    
    while(current_level < 4 && is_win) {
        cnt_boom = std::max(3, cnt_boom);
        Welcome();
        x = 1, y = 1;
        flag = 1;
        val = 0;
        print();
        start = time(nullptr);
        
        auto lastDisplayTime = std::chrono::steady_clock::now();
        const int DISPLAY_INTERVAL_MS = 100;
        
        while(true) {
            time_t currentTime = time(nullptr);
            if(currentTime - start > wait_time) {
                is_win = 0;
                break;
            }
            
            auto now = std::chrono::steady_clock::now();
            auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastDisplayTime).count();
            if(elapsed >= DISPLAY_INTERVAL_MS) {
                lastDisplayTime = now;
                print();
            }
            
            if(keyPressed()) {
                char key = getKey();
                
                if(key == ' ') {
                    if(!lastSpacePressed) {
                        Break_wall();
                        lastSpacePressed = true;
                        print();
                    }
                } else {
                    lastSpacePressed = false;
                    if(key == 'w') W();
                    else if(key == 'a') A();
                    else if(key == 's') S();
                    else if(key == 'd') D();
                    else if(key == 'r') Get_Boom();
                    
                    if(f[x][y] == 2) {
                        val++;
                        f[x][y] = 0;
                    }
                    
                    print();
                    
                    if(x == fx && y == fy) {
                        advcsr.clear();
                        break;
                    }
                }
            } else {
                lastSpacePressed = false;
            }
            
            wait_ms(10);
        }
        
        Ending(is_win);
        if(is_win) current_level++;
    }
    
    THEEND(is_win);
    advcsr.show();
    return 0;
}