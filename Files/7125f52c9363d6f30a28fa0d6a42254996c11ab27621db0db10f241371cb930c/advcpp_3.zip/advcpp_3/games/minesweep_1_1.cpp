// g++ minesweep_1_1.cpp -o minesweep_1_1 -std=c++17 && ./minesweep_1_1
#include "../advin.hpp"
#include "../advout.hpp"
#include "../advcsr.hpp"
// #include <queue>
#include <random>
#include <chrono>
#include <cmath>

int random_int(int min, int max) {
    static std::mt19937 generator(
        static_cast<unsigned>(
            std::chrono::system_clock::now().time_since_epoch().count()
        )
    );
    
    // Normal distribution (bell curve) centered in middle
    int center = (min + max) / 2;
    int range = max - min;
    double stddev = range / 4.0;  // 95% within ±2σ
    
    std::normal_distribution<double> distribution(center, stddev);
    
    // Clamp to range
    double value = distribution(generator);
    if (value < min) value = min;
    if (value > max) value = max;
    
    return static_cast<int>(value);
}

// Triangular distribution (more likely in middle)
int triangular_random(int min, int max) {
    static std::mt19937 generator(
        static_cast<unsigned>(
            std::chrono::system_clock::now().time_since_epoch().count()
        )
    );
    
    std::uniform_real_distribution<double> dist(0.0, 1.0);
    double u = dist(generator);
    
    // Triangular distribution
    double value;
    if (u <= 0.5) {
        value = min + (max - min) * sqrt(u * 0.5);
    } else {
        value = max - (max - min) * sqrt((1 - u) * 0.5);
    }
    
    return static_cast<int>(value);
}

using namespace adv;
using namespace std;

const int X=20, Y=10;

bool mf[X][Y];
int cnt[X][Y];
bool flipped[X][Y];
bool bgc[X][Y];
int hardness = 0;
int percentage;

bool quitting=0;

void ask_quit(){
    advout.printline("Are you sure to quit?");
    char input=advin.wait_press_char();
    if (input=='Y' || input=='y') quitting=1;
}

int main(){
    if (!advout.hasAnsi() && !advout.hasWinConsoleColors()){
        advout<<"\nOops! :(\n";
        advout<<"This application needs color support to run.\n";
        advout<<"Please use a different terminal or environment.\n";
        return 0;
    }

    advcsr.hide();
    while (true) {
        // hoem screen
        char input='\0';
        while (input!='\r'&&input!='\n'){
            advout.clearScreen();
            advcsr.gotoxy(6,3);
            advout.printline("Welcome to Minesweep!");
            advout.endl();
            advout<<"       ";
            if (hardness==0){
                advout.setBackgroundColor(GREEN);
                advout<<"easy"; advout.reset_bg_color();
            } else {
                advout<<"easy";
            } advout<<' ';
            if (hardness==1){
                advout.setBackgroundColor(YELLOW);
                advout<<"moderate"; advout.reset_bg_color();
            } else {
                advout<<"moderate";
            } advout<<' ';
            if (hardness==2){
                advout.setBackgroundColor(RED);
                advout<<"hard"; advout.reset_bg_color();
            } else {
                advout<<"hard";
            } advout<<"         \n                                  \n           GO! [enter]            \n";
            advout.flush();
            input=advin.wait_press_char();
            if (input=='a' || input=='A') hardness=(hardness+2)%3;
            if (input=='d' || input=='D') hardness=(hardness+1)%3;
            if (input=='q' || input=='Q') ask_quit(); if (quitting) break;
        }
        if (quitting){
            advout.clearScreen();
            advout<<"Program exited with return code 114514\n";
            advout.flush(); break;
        }
        advout.clearScreen();
        advout.printline("Loading...");
        switch (hardness){
            case 0: percentage=10; break;
            case 1: percentage=20; break;
            case 2: percentage=30; break;
        }
        int total_mines=0;

        auto distance_to_center=[](int i, int j, int X, int Y) {
            float center_i = (X - 1) / 2.0f;
            float center_j = (Y - 1) / 2.0f;
            float dx = i - center_i;
            float dy = j - center_j;
            return sqrt(dx*dx + dy*dy);
        };
        auto max_distance=[&distance_to_center](int X, int Y) {
            return distance_to_center(0, 0, X, Y);
        };

        float bias=2.0f;
        float max_dist = max_distance(X, Y);
        for(int i = 0; i < X; i++) {
            for(int j = 0; j < Y; j++) {
                float dist = distance_to_center(i, j, X, Y);
                float normalized_dist = dist / max_dist; 
                
                float center_factor = 1.0f + (bias - 1.0f) * (1.0f - normalized_dist);
                float effective_percentage = percentage * center_factor;
                
                if(effective_percentage > 100.0f) effective_percentage = 100.0f;
                
                mf[i][j] = random_int(0, 100) <= effective_percentage;
                flipped[i][j] = false;
                bgc[i][j] = random_int(0, 1000) < 500;
                if (mf[i][j]) total_mines++;
            }
        }
        for(int i=0; i<X; i++){
            for(int j=0; j<Y; j++){
                cnt[i][j]=0;
                if (i>0){
                    if (j>0 && mf[i-1][j-1]) cnt[i][j]++;
                    if (mf[i-1][j]) cnt[i][j]++;
                    if (j<Y-1 && mf[i-1][j+1]) cnt[i][j]++;
                }
                if (j>0 && mf[i][j-1]) cnt[i][j]++;
                if (j<Y-1 && mf[i][j+1]) cnt[i][j]++;
                if (i<X-1){
                    if (j>0 && mf[i+1][j-1]) cnt[i][j]++;
                    if (mf[i+1][j]) cnt[i][j]++;
                    if (j<Y-1 && mf[i+1][j+1]) cnt[i][j]++;
                }
            }
        }
        advout.clearScreen();
        if (1){ // debugging use
            for(int j=0; j<Y; j++){
                for(int i=0; i<X; i++){
                    advout<<mf[i][j];
                }
                advout.endl();
            }
        }
        int sx=0, sy=0, score=0;
        bool gameEnd=0;
        advout.printline("Here we go!");
        wait_s(1);
        while(true){
            input='\0';
            while (input!='\r'&&input!='\n'){
                advout.clearScreen();
                for(int j=0; j<Y; j++){
                    for(int i=0; i<X; i++){
                        if (sx==i&&sy==j) advout.setBackgroundColor(BLUE);
                        else if (flipped[i][j]) advout.setBackgroundColor(YELLOW);
                        else advout.setBackgroundColor(bgc[i][j]?GREEN:BRIGHT_GREEN);
                        if (flipped[i][j]) advout<<cnt[i][j];
                        else advout<<' ';
                        advout.reset_bg_color();
                    }
                    advout.endl();
                }
                advout.print("score: %d\n", score);
                advout.flush();
                input=advin.wait_press_char();
                if ((input=='a' || input=='A') && sx>0) sx--;
                if ((input=='d' || input=='D') && sx<X-1) sx++;
                if ((input=='w' || input=='W') && sy>0) sy--;
                if ((input=='s' || input=='S') && sy<Y-1) sy++;
                if (input=='q' || input=='Q') ask_quit(); if (quitting) break;
            }
            if (quitting) break;
            if (!flipped[sx][sy]){
                flipped[sx][sy]=1;
                if (mf[sx][sy]){
                    gameEnd=1;
                } else {
                    score++;
                    // queue<pair<int, int> > bfs; // BFS for Windows
                    // TODO: Make the search for the patch of 0s.
                    if (score==X*Y-total_mines){
                        gameEnd=1;
                    }
                }
            }
            if (gameEnd){
                advout.clearScreen();
                for(int j=0; j<Y; j++){
                    for(int i=0; i<X; i++){
                        if (mf[i][j]){
                            advout.setBackgroundColor(RED);
                            advout<<' ';
                        }
                        else if (flipped[i][j]){
                            advout.setBackgroundColor(YELLOW);
                            advout<<cnt[i][j];
                        }
                        else {
                            advout.setBackgroundColor(bgc[i][j]?GREEN:BRIGHT_GREEN);
                            advout<<' ';
                        }
                        advout.reset_bg_color();
                    }
                    advout.endl();
                }
                if (mf[sx][sy]) advout.print("You lose! score: %d\n", score);
                else advout.print("You win! score: %d\n", score);
                advout.print("Press E to exit the game");
                advout.flush();
                input='\0';
                while(input!='q' && input!='Q' && input!='\n' && input!='\r' && input!='E' && input!='e'){
                    input=advin.wait_press_char();
                }
                if (input=='q' || input=='Q') ask_quit();
                break;
            }
        }
        if (quitting){
            advout.clearScreen();
            advout<<"Program exited with return code 114514\n";
            advout.flush(); break;
        }
    }
    return 1910;
}