// TODO: Complete the Table Utilities

// #include <iostream>
#include <cstddef>
#include <vector>

namespace adv {
    // Utilities for tables
    template<class T>
    class table{
    private:
        class row{
        public:
            std::vector<T> data;
            row operator[](size_t index){
                return data[index];
            }
        };
        std::vector<row> data;
    public:
        void setData(T init){

        }
        row operator[](size_t index){
            return data[index];
        }
    };
}