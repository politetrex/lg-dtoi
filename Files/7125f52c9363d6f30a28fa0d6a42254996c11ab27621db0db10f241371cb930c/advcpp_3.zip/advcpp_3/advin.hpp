#ifndef ADVIN_HPP
#define ADVIN_HPP

#include <iostream>
#include <string>
#include <limits>

#ifdef _WIN32
#include <conio.h>
#include <windows.h>
#else
#include <termios.h>
#include <unistd.h>
#endif

namespace adv {

class DualSupportInput {
public:
    // Get a single character (no Enter needed)
    char wait_press_char() {
#ifdef _WIN32
        return _getch();
#else
        struct termios oldt, newt;
        char ch;
        
        // Save old terminal settings
        tcgetattr(STDIN_FILENO, &oldt);
        newt = oldt;
        
        // Disable echo and line buffering
        newt.c_lflag &= ~(ICANON | ECHO);
        tcsetattr(STDIN_FILENO, TCSANOW, &newt);
        
        // Read character
        read(STDIN_FILENO, &ch, 1);
        
        // Restore terminal settings
        tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
        
        return ch;
#endif
    }
    
    // Get password (hidden input)
    std::string get_password(const std::string& prompt = "", char mask = '*') {
        if (!prompt.empty()) {
            std::cout << prompt << std::flush;
        }
        
        std::string password;
        char ch;
        
#ifdef _WIN32
        while ((ch = _getch()) != 13) {  // 13 = Enter
            if (ch == 8) {  // Backspace
                if (!password.empty()) {
                    password.pop_back();
                    std::cout << "\b \b" << std::flush;
                }
            } else if (ch >= 32 && ch < 127) {
                password.push_back(ch);
                std::cout << mask << std::flush;
            }
        }
#else
        struct termios oldt, newt;
        tcgetattr(STDIN_FILENO, &oldt);
        newt = oldt;
        newt.c_lflag &= ~ECHO;  // Disable echo
        tcsetattr(STDIN_FILENO, TCSANOW, &newt);
        
        // Read characters one by one
        while (read(STDIN_FILENO, &ch, 1) == 1 && ch != '\n' && ch != '\r') {
            if (ch == 127 || ch == 8) {  // Backspace/Delete
                if (!password.empty()) {
                    password.pop_back();
                    std::cout << "\b \b" << std::flush;
                }
            } else if (ch >= 32 && ch < 127) {
                password.push_back(ch);
                std::cout << mask << std::flush;
            }
        }
        
        // Restore terminal
        tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
#endif
        
        std::cout << std::endl;
        return password;
    }
    
    // Clear input buffer
    void clear_buffer() {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    
    // Wait for any key with message
    void wait_key(const std::string& message = "Press any key to continue...") {
        std::cout << message << std::flush;
        wait_press_char();
        std::cout << std::endl;
    }
    
    // Stream operator for chaining
    template<typename T>
    DualSupportInput& operator>>(T& value) {
        std::cin >> value;
        return *this;
    }
};

// Specialization for std::string
template<>
inline DualSupportInput& DualSupportInput::operator>><std::string>(std::string& value) {
    std::getline(std::cin, value);
    return *this;
}

// Global instance
static DualSupportInput advin;

} // namespace adv

#endif // ADVIN_HPP