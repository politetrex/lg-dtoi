#include "../advcsr.hpp"
#include "../advout.hpp"
#include "../advin.hpp"

using namespace adv;
using namespace std;

int main() {
    advout.clearScreen();
    advcsr.gotoxy(10, 10);
    advout<<"Hello from the ADV I/O Centre!\n";
    advout.flush();
    std::string mass=advin.get_password("Password:", '\0');
    advout<<"Uh-oh, you're "<<mass<<"!\n";
    // clang++ ./advin.cpp ./advout.cpp ./cursor.cpp ./examples/cs.cpp -std=c++20 -o propram
    return 0;
}