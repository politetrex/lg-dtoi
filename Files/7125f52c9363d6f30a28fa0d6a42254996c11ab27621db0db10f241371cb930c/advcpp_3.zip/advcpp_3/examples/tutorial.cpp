// Compile command/编译指令/����ָ��: 
// g++ ../advout.cpp ./tutorial.cpp -o program 

#include "../advout.hpp"
using namespace adv;
int main(){
    advout.printline("=====================================================");
    advout<<"Welcome to the tutorial of ";
    advout.setAttribute(BOLD);
    advout<<"advout!"; advout.reset_attributes();
    advout.reset_colors(); advout.endl();
    advout.printline("How to use? Don't worry!");
    advout.setAttribute(BOLD);
    advout.printline("Print a line (easier)");
    advout.reset_attributes();
    advout.printline("advout.printline(\"The line needed to print\");");
    advout.setAttribute(BOLD);
    advout.printline("Print anything (mutable)");
    advout.reset_attributes();
    advout.printline("advout<<\"Sam is \"<<3<<\" years old\";");
    advout.setAttribute(BOLD);
    advout.printline("Environment info");
    advout.reset_attributes();
    advout.printline("advout.showInfo();");
    if (advout.hasAnsi()){
        advout.setAttribute(BOLD);
        advout.printline("Colourtime");
        advout.reset_attributes(); advout.setForegroundColor(RED);
        advout.printline("advout.setForegroundColor(RED);");
        advout.setForegroundColor(BRIGHT_YELLOW);
        advout.printline("advout.setForegroundColor(BRIGHT_YELLOW);");
        advout.setBackgroundColor(BLACK);
        advout.printline("advout.setBackgroundColor(BLACK);");
        advout.setBackgroundColor(BLUE);
        advout.printline("advout.setBackgroundColor(BLUE);");
        advout.setBackgroundColor(RESET_COLOR);
        advout.printline("advout.setBackgroundColor(RESET_COLOR);");
        advout.setForegroundColor(RESET_COLOR);
        advout.printline("advout.setForegroundColor(RESET_COLOR);");
        advout.setColor(RED, GREEN);
        advout.printline("advout.setColor(RED, GREEN);");
        advout.setForegroundColor(133, 233, 33);
        advout.printline("advout.setForegroundColor(133, 233, 33);");
        advout.setBackgroundColor(244, 233, 222);
        advout.printline("advout.setBackgroundColor(244, 233, 222);");
        advout.setColor(YELLOW, GRAY);
        advout.printline("advout.setColor(YELLOW, GRAY);");
        advout.setColor(YELLOW, 250, 250, 250);
        advout.printline("advout.setColor(YELLOW, 250, 250, 250);");
        advout.setColor(75, 75, 150, 150, 225, 225);
        advout.printline("advout.setColor(75, 75, 150, 150, 225, 225);");
        advout.reset_colors();
        advout.printline("advout.reset_colors();");
        advout.setAttribute(BOLD);
        advout.printline("Font party");
        advout.reset_attributes();
        advout<<"advout.setAttribute(...)";advout.endl();
        advout.setAttribute(BOLD); advout<<"BOLD"; advout.reset_attributes();
        advout.setAttribute(FAINT); advout<<"FAINT"; advout.reset_attributes();
        advout.setAttribute(ITALIC); advout<<"ITALIC"; advout.reset_attributes();advout.endl();
        advout.setAttribute(UNDERLINE); advout<<"UNDERLINE"; advout.reset_attributes();advout.endl();
        // advout.setAttribute(adv::BLINK_SLOW); advout<<"BLINK_SLOW\n"; advout.reset_attributes();
        // advout.setAttribute(adv::BLINK_FAST); advout<<"BLINK_FAST\n"; advout.reset_attributes();
        advout.setAttribute(adv::REVERSE); advout<<"REVERSE"; advout.reset_attributes();advout.endl();
        advout<<"CONCEAL: (copy what's after this)";
        advout.setAttribute(adv::CONCEAL); advout<<"CONCEAL"; advout.reset_attributes();
        advout.endl();
        advout.setAttribute(adv::STRIKETHROUGH); advout<<"STRIKETHROUGH"; advout.reset_attributes();
        advout.endl();
    }
    advout.printline("The next operation will be clearing the screen.");
    advout.printline("Press Enter to continue.");
    wait_until_enter(); advout.clearScreen();
    advout.printline("See? I used clearScreen() to do this.");
    advout.printline("And I would make some intresting things.");
    wait_s(5);
    advout.clearScreen(); advout.printline("3 "); wait_s(1);
    advout.clearScreen(); advout.printline("2 "); wait_s(1);
    advout.clearScreen(); advout.printline("1 "); wait_s(1);
    advout.clearScreen(); 
	advout<<"A countdown! Isn't it fun?\n";
	advout.printline("Press Enter to finish the tutorial and start coding!");
    wait_until_enter(); 
    return 0;
}
