#include "../advout.hpp"
using namespace adv;
void typeText(std::string s, unsigned int time_ms=100) {
    for(auto& i:s){
        advout<<i; advout.flush(); wait_ms(time_ms);
    }
}
int main(){
    typeText("实施中华的事，筑中华之梦！", 50);
    return 0;
}