#include "../advout.hpp"
#include <array>
#include <chrono>
#include <mutex>
// #include <format> 
using namespace adv;
using namespace std; 
array<int, 7> datetime() {
    static mutex mtx;
    
    auto now = chrono::system_clock::now();
    auto time = chrono::system_clock::to_time_t(now);
    
    tm local_time;
    {
        lock_guard<mutex> lock(mtx);
        local_time = *localtime(&time);
    }
    
    return array<int, 7>{
        local_time.tm_year + 1900,
        local_time.tm_mon + 1,
        local_time.tm_mday,
        local_time.tm_hour,
        local_time.tm_min,
        local_time.tm_sec,
        local_time.tm_wday
    };
}
const char* months[12]= {"Jan", "Feb", "Mar", "Apr", "May", "Jun", 
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
const char* weeks[7]={"Sun", "Mon", "Tue", "Wed", 
    "Thu", "Fri", "Sat"};
int main(){
    while(1){
        {
            advout.clearScreen();
            auto tm=datetime();
            advout.print("Date: %s %02d %s %04d %02d:%02d:%02d\n", 
                weeks[tm[6]], tm[2], months[tm[1]-1], 
                tm[0], tm[3], tm[4], tm[5]);
            advout.flush();
            wait_s(1);
        }
        {
            advout.clearScreen();
            auto tm=datetime();
            advout.print("Date: %s %02d %s %04d %02d %02d %02d\n", 
                weeks[tm[6]], tm[2], months[tm[1]-1], 
                tm[0], tm[3], tm[4], tm[5]);
            advout.flush();
            wait_s(1);
        }
    }
}