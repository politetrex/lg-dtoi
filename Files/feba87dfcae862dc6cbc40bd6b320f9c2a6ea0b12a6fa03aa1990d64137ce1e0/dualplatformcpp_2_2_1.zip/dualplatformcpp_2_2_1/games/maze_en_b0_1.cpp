#include <vector>
#include <stack>
#include <random>
#include <algorithm>
#include <chrono>
#include "../adv.hpp"

using namespace std;
using namespace adv;

// Code by DeepSeek
class ComplexMazeGenerator {
private:
    int rows, cols;
    mt19937 rng;
    
    struct Cell {
        int row, col;
        Cell(int r, int c) : row(r), col(c) {}
    };
    
    // Get all four directional neighbors
     vector<pair<int, int> > getNeighbors(int r, int c) {
         vector<pair<int, int> > neighbors;
        int dirs[4][2] = {{-2, 0}, {2, 0}, {0, -2}, {0, 2}};
        
        for(auto& dir : dirs) {
            int nr = r + dir[0];
            int nc = c + dir[1];
            if(nr >= 0 && nr < rows && nc >= 0 && nc < cols) {
                neighbors.push_back({nr, nc});
            }
        }
        return neighbors;
    }
    
    // Get unvisited neighbors
     vector<pair<int, int> > getUnvisitedNeighbors(int r, int c, vector<vector<bool> >& visited) {
         vector<pair<int, int> > unvisited;
        auto neighbors = getNeighbors(r, c);
        
        for(auto& n : neighbors) {
            if(!visited[n.first][n.second]) {
                unvisited.push_back(n);
            }
        }
        return unvisited;
    }
    
    // Remove wall between two cells
    void carvePath(int r1, int c1, int r2, int c2) {
        int wallR = (r1 + r2) / 2;
        int wallC = (c1 + c2) / 2;
        maze[wallR][wallC] = true;
    }
    
    // Create entrance and exit
    void createEntranceExit() {
        // Entrance at top-left area
        /*
        for(int c = 1; c < cols; c += 2) {
            if(maze[1][c]) {
                maze[0][c] = true;
                break;
            }
        }
        */
        
        // Exit at bottom-right area
        for(int c = cols-2; c >= 0; c -= 2) {
            if(maze[rows-2][c]) {
                maze[rows-1][c] = true;
                break;
            }
        }
    }

public:
    vector<vector<bool> > maze;
    ComplexMazeGenerator(int r, int c) : rng(chrono::steady_clock::now().time_since_epoch().count()) {
        // Ensure odd dimensions for proper maze generation
        rows = (r % 2 == 0) ? r + 1 : r;
        cols = (c % 2 == 0) ? c + 1 : c;
        
        // Initialize maze with all walls (false)
        maze = vector<vector<bool> >(rows, vector<bool>(cols, false));
    }
    
    // Recursive Backtracking with weighted randomness for more complexity
    void generateRecursiveBacktracking() {
        vector<vector<bool> > visited(rows, vector<bool>(cols, false));
        stack<Cell> stack;
        
        // Start from random odd cell
        uniform_int_distribution<int> rowDist(1, rows-2);
        uniform_int_distribution<int> colDist(1, cols-2);
        
        int startR = rowDist(rng);
        int startC = colDist(rng);
        
        // Ensure start position is odd
        if(startR % 2 == 0) startR--;
        if(startC % 2 == 0) startC--;
        
        visited[startR][startC] = true;
        maze[startR][startC] = true;
        stack.push(Cell(startR, startC));
        
        while(!stack.empty()) {
            Cell current = stack.top();
            
            auto neighbors = getUnvisitedNeighbors(current.row, current.col, visited);
            
            if(!neighbors.empty()) {
                // Weighted random selection for more complex patterns
                 vector<pair<int, int> > weightedNeighbors;
                for(auto& n : neighbors) {
                    // Add multiple copies based on position for weighting
                    int weight = 1;
                    
                    // Prefer directions that create longer corridors
                    if(abs(n.first - current.row) > abs(n.second - current.col)) {
                        weight += 2; // Vertical preference
                    } else {
                        weight += 1; // Horizontal preference
                    }
                    
                    // Add more weight to edges for complexity
                    if(n.first <= 1 || n.first >= rows-2 || n.second <= 1 || n.second >= cols-2) {
                        weight += 3;
                    }
                    
                    for(int w = 0; w < weight; w++) {
                        weightedNeighbors.push_back(n);
                    }
                }
                
                uniform_int_distribution<int> dist(0, weightedNeighbors.size() - 1);
                auto& next = weightedNeighbors[dist(rng)];
                
                carvePath(current.row, current.col, next.first, next.second);
                visited[next.first][next.second] = true;
                maze[next.first][next.second] = true;
                
                stack.push(Cell(next.first, next.second));
            } else {
                stack.pop();
                
                // Occasionally add branching from visited cells (but no loops)
                if(stack.empty() && !isComplete(visited)) {
                    // Find any unvisited cell adjacent to visited area
                    for(int i = 1; i < rows; i += 2) {
                        for(int j = 1; j < cols; j += 2) {
                            if(!visited[i][j]) {
                                auto neighbors = getNeighbors(i, j);
                                for(auto& n : neighbors) {
                                    if(visited[n.first][n.second]) {
                                        carvePath(n.first, n.second, i, j);
                                        visited[i][j] = true;
                                        maze[i][j] = true;
                                        stack.push(Cell(i, j));
                                        break;
                                    }
                                }
                                if(!stack.empty()) break;
                            }
                        }
                        if(!stack.empty()) break;
                    }
                }
            }
        }
        
        createEntranceExit();
    }
    
    void generateHuntAndKill() {
        vector<vector<bool> > visited(rows, vector<bool>(cols, false));
        
        // Start from random odd cell
        uniform_int_distribution<int> rowDist(1, rows-2);
        uniform_int_distribution<int> colDist(1, cols-2);
        
        int currentR = rowDist(rng);
        int currentC = colDist(rng);
        
        if(currentR % 2 == 0) currentR--;
        if(currentC % 2 == 0) currentC--;
        
        visited[currentR][currentC] = true;
        maze[currentR][currentC] = true;
        
        // Kill phase - random walk
        while(true) {
            auto unvisited = getUnvisitedNeighbors(currentR, currentC, visited);
            
            if(!unvisited.empty()) {
                // Randomly choose next cell
                uniform_int_distribution<int> dist(0, unvisited.size() - 1);
                auto& next = unvisited[dist(rng)];
                
                carvePath(currentR, currentC, next.first, next.second);
                visited[next.first][next.second] = true;
                maze[next.first][next.second] = true;
                
                currentR = next.first;
                currentC = next.second;
            } else {
                // Hunt phase - find new start cell
                bool found = false;
                
                // Hunt in spiral pattern for complexity
                for(int radius = 2; radius < max(rows, cols); radius += 2) {
                    for(int dr = -radius; dr <= radius; dr += 2) {
                        for(int dc = -radius; dc <= radius; dc += 2) {
                            if(abs(dr) == radius || abs(dc) == radius) {
                                int hr = currentR + dr;
                                int hc = currentC + dc;
                                
                                if(hr >= 1 && hr < rows-1 && hc >= 1 && hc < cols-1 && 
                                   hr % 2 == 1 && hc % 2 == 1 && !visited[hr][hc]) {
                                    
                                    auto neighbors = getNeighbors(hr, hc);
                                    for(auto& n : neighbors) {
                                        if(visited[n.first][n.second]) {
                                            carvePath(n.first, n.second, hr, hc);
                                            visited[hr][hc] = true;
                                            maze[hr][hc] = true;
                                            currentR = hr;
                                            currentC = hc;
                                            found = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            if(found) break;
                        }
                        if(found) break;
                    }
                    if(found) break;
                }
                
                if(!found) break;
            }
        }
        
        createEntranceExit();
    }
    
    // Check if all odd cells are visited
    bool isComplete(vector<vector<bool> >& visited) {
        for(int i = 1; i < rows; i += 2) {
            for(int j = 1; j < cols; j += 2) {
                if(!visited[i][j]) return false;
            }
        }
        return true;
    }
    
    // Add texture (dead ends, turns) without creating loops
    void addTexture() {
        // Add small dead ends to existing paths
        for(int i = 1; i < rows-1; i += 2) {
            for(int j = 1; j < cols-1; j += 2) {
                if(maze[i][j]) {
                    // Try to add a small dead end
                    int dirs[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
                    shuffle(&dirs[0], &dirs[4], rng);
                    
                    for(auto& dir : dirs) {
                        int wallR = i + dir[0];
                        int wallC = j + dir[1];
                        int nextR = i + dir[0]*2;
                        int nextC = j + dir[1]*2;
                        
                        // Check if we can add a dead end without creating a loop
                        if(wallR >= 0 && wallR < rows && wallC >= 0 && wallC < cols &&
                           nextR >= 0 && nextR < rows && nextC >= 0 && nextC < cols) {
                            if(!maze[wallR][wallC] && !maze[nextR][nextC]) {
                                // Count paths around the potential new cell
                                int pathCount = 0;
                                int checkDirs[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
                                for(auto& cd : checkDirs) {
                                    int checkR = nextR + cd[0];
                                    int checkC = nextC + cd[1];
                                    if(checkR >= 0 && checkR < rows && 
                                       checkC >= 0 && checkC < cols && 
                                       maze[checkR][checkC]) {
                                        pathCount++;
                                    }
                                }
                                
                                // If only one path would connect, it's safe (dead end)
                                if(pathCount <= 1) {
                                    maze[wallR][wallC] = true;
                                    maze[nextR][nextC] = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    // Print maze with nice formatting
    void printMaze(int x, int y) {
        for(int i = 0; i < rows; i++) {
            for(int j = 0; j < cols; j++) {
                if (i==x&&j==y){
                    advout<<"O";
                } else if(maze[i][j] && i) { // spawn at 1,1
                    // Path
                    if((i == rows-1) && maze[i][j]) {
                        advout << "X"; // Exit
                    } else {
                        advout << " "; // Regular path
                    }
                } else {
                    advout << "W";
                }
            }
            advout<<'\n';
        }
    }
};
bool hasPathToEnd(vector<vector<bool>>& maze, int endR, int endC) {
    int rows = maze.size();
    int cols = maze[0].size();
    
    // BFS to find path
    vector<vector<bool>> visited(rows, vector<bool>(cols, false));
    queue<pair<int, int>> q;
    
    // Start from (1,1)
    if(maze[1][1]) {
        q.push({1, 1});
        visited[1][1] = true;
    }
    
    int dirs[4][2] = {{-1,0}, {1,0}, {0,-1}, {0,1}};
    
    while(!q.empty()) {
        auto [r, c] = q.front();
        q.pop();
        
        // Check if reached end
        if(r == endR && c == endC) {
            return true;
        }
        
        // Check all 4 directions
        for(auto& dir : dirs) {
            int nr = r + dir[0];
            int nc = c + dir[1];
            
            if(nr >= 0 && nr < rows && nc >= 0 && nc < cols && 
               maze[nr][nc] && !visited[nr][nc]) {
                visited[nr][nc] = true;
                q.push({nr, nc});
            }
        }
    }
    
    return false;
}

int main() {
    ComplexMazeGenerator mazeGen(16, 36);
    mt19937 main_gen;
    int endIndex;
    do {
        if (main_gen()%2)
            mazeGen.generateRecursiveBacktracking();
        else
            mazeGen.generateHuntAndKill();
        endIndex=35;
        while(!mazeGen.maze[15][endIndex]) endIndex--;
    } while (!hasPathToEnd(mazeGen.maze, 15, endIndex));
    auto maze=mazeGen.maze;

    // Code by politetrex - home screen
    advout.setAttribute(REVERSE);
    advout.printline("|\\  /|   /\\   ---/ /----");
    advout.printline("| \\/ |  /--\\   /`  |----");
    advout.printline("|    | /    \\ /--- \\----");
    advout.printline("   - English Edition 1.0");
    advin.wait_key("Press any key to enter...");
    // Code by DeepSeek
    int x = 1, y = 1;  // Start at (1,1) where path begins
    while(x != 16 || y != endIndex){
        advout.clearScreen();
        mazeGen.printMaze(x, y);  // Pass current position
        char key = advin.wait_press_char();
        
        if ((key=='w' or key=='W') and x > 0 and maze[x-1][y]) x--;  // Check maze[x-1][y] is true (path)
        if ((key=='a' or key=='A') and y > 0 and maze[x][y-1]) y--;  // Check maze[x][y-1] is true
        if ((key=='s' or key=='S') and x < 16 and maze[x+1][y]) x++;  // Check maze[x+1][y] is true
        if ((key=='d' or key=='D') and y < 35 and maze[x][y+1]) y++;  // Check maze[x][y+1] is true
    }
    return 0;
}


/*





*/